const { useState, useEffect } = React

export function Home() {
    return (
        <section className="home">
            <h2>Home Sweet Home</h2>
       </section>
    )
}

